package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    Button plus1;
    Button minus1;
    TextView expenses;
    int counter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Bundle l = getIntent().getExtras();
        String r = l.getString("info");


        expenses = findViewById(R.id.textView3);
        plus1 = findViewById(R.id.Plus);
        minus1 = findViewById(R.id.Minus);
        counter = Integer.parseInt(r);

        expenses.setText(r + "");

        plus1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                counter ++;
                expenses.setText(counter + "" + "KD");
            }
        });

        minus1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                counter --;
                expenses.setText(counter + "" + "KD");
            }
        });

    }
}